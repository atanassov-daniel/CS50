#include <stdio.h>

int main(void)
{
    int n = 50;
    // errors
    // printf("address = %i\n", &n); => format specifies type 'int' but the argument has type 'int *' [-Werror,-Wformat]
    // printf("address = %x\n", &n); => format specifies type 'unsigned int' but the argument has type 'int *' [-Werror,-Wformat]
    // printf("address = %p\n", &50); => cannot take the address of an rvalue of type 'int'
    // printf("address = %p\n", 50); => format specifies type 'void *' but the argument has type 'int' [-Werror,-Wformat]

    // printf("number = %i\n", n); => number = 50
    // printf("address = %p\n", &n); => address = 0x7ffc58328efc
    printf("number = %i\n", *&n); // undoing the effect of &n => number = 50

}
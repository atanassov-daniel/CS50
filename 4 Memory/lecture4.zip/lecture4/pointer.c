#include <stdio.h>
// we can print out the address of N by temporarirly storing it in a variable
int main(void)
{
    int n = 50;
    int *p = &n;
    // printf("address = %p\n", p); => address = 0x7ffe7162183c // its type is int *
    // if we don't want to print the address of n, but to print n itself using p
    // printf("number = %i\n", *p); => number = 50

    // printf("address = %p\n", &p); // 0x7ffc3aed0aa0 // its type is int **
    printf("address = %p\n", &(&p)); // cannot take the address of an rvalue of type 'int **'
}